package ru.team.mutegui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Открывается по клавише M: список онлайн-игроков или ручной ввод ника. */
public class MuteTargetScreen extends Screen {
    private static final int ROW_H = 20;
    private static final int LIST_TOP = 60;
    private static final int LIST_WIDTH = 200;

    private TextFieldWidget nameField;
    private final List<String> names = new ArrayList<>();
    private int scroll = 0;

    public MuteTargetScreen() {
        super(Text.literal("Кого замутить?"));
    }

    @Override
    protected void init() {
        MinecraftClient mc = MinecraftClient.getInstance();
        names.clear();
        if (mc.player != null && mc.player.networkHandler != null) {
            for (PlayerListEntry entry : mc.player.networkHandler.getPlayerList()) {
                String n = entry.getProfile().getName();
                if (n != null && !n.isEmpty() && !names.contains(n)) {
                    names.add(n);
                }
            }
        }
        names.sort(Comparator.naturalOrder());

        nameField = new TextFieldWidget(textRenderer, width / 2 - LIST_WIDTH / 2, 25, LIST_WIDTH - 65, 20,
                Text.literal("Ник игрока"));
        nameField.setMaxLength(32);
        addDrawableChild(nameField);
        setInitialFocus(nameField);

        addDrawableChild(ButtonWidget.builder(Text.literal("Далее"), btn -> openFor(nameField.getText().trim()))
                .dimensions(width / 2 + LIST_WIDTH / 2 - 60, 25, 60, 20).build());
    }

    private void openFor(String target) {
        if (target == null || target.isEmpty()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        mc.player.networkHandler.sendChatCommand(MuteModClient.CONFIG.openCommand);
        mc.setScreen(new MuteScreen(target));
    }

    private int maxShown() {
        return Math.max(1, (height - LIST_TOP - 10) / ROW_H);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, 10, 0xFF5555);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Онлайн (нажми на ник, колесо мыши — прокрутка):"),
                width / 2, 50, 0xAAAAAA);

        int shown = 0;
        int max = maxShown();
        for (int i = scroll; i < names.size() && shown < max; i++, shown++) {
            int rowY = LIST_TOP + shown * ROW_H;
            boolean hovered = mouseX > width / 2 - LIST_WIDTH / 2 && mouseX < width / 2 + LIST_WIDTH / 2
                    && mouseY >= rowY && mouseY < rowY + ROW_H - 2;
            int color = hovered ? 0xFFFFFF55 : 0xFFFFFFFF;
            ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(names.get(i)), width / 2, rowY + 5, color);
        }

        if (names.isEmpty()) {
            ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Список игроков пуст"), width / 2, LIST_TOP + 10, 0xFF8888);
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int shown = 0;
        int max = maxShown();
        for (int i = scroll; i < names.size() && shown < max; i++, shown++) {
            int rowY = LIST_TOP + shown * ROW_H;
            if (mouseX > width / 2 - LIST_WIDTH / 2 && mouseX < width / 2 + LIST_WIDTH / 2
                    && mouseY >= rowY && mouseY < rowY + ROW_H - 2) {
                openFor(names.get(i));
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scroll -= (int) Math.signum(verticalAmount);
        int maxScroll = Math.max(0, names.size() - maxShown());
        if (scroll < 0) scroll = 0;
        if (scroll > maxScroll) scroll = maxScroll;
        return true;
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
